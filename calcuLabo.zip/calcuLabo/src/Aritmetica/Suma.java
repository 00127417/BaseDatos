/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aritmetica;

/**
 *
 * @author LN710Q
 */
public class Suma implements Aritmetica{

    
    @Override
    public double calcular(double var1, double var2) {
        return var1+var2;
    }

    
}
