/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Conversor;

import Aritmetica.Aritmetica;
import calculabo.AbstractFactory;

/**
 *
 * @author LN710Q
 */
public class FactoryConversor implements AbstractFactory{

    @Override
    public Aritmetica getAritmetica(String type) {
       return null;
    }

    @Override
    public Conversor gerConversor(String type) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
