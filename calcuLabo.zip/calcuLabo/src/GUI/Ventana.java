/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GUI;
import Aritmetica.Aritmetica;
import Conversor.Conversor;
import calculabo.AbstractFactory;
import calculabo.operacionProducer;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author LN710Q
 */
public class Ventana extends JPanel{
    AbstractFactory operacionA,operacionC;
    public int WIDTH=300,widthTF=40,widthB=80;
    public int HEIGHT=300,heightTF=30,heightB=30;
    public JTextField textF1,textF2,textF3;
    public JButton button;
    public Ventana() {
        operacionA=operacionProducer.getOperacion("o");
        operacionC=operacionProducer.getOperacion("c");
        Aritmetica suma=operacionA.getAritmetica("+");
        textF1=new JTextField();
        textF1.setBounds(new Rectangle(50,40,widthTF,heightTF));
        textF2=new JTextField();
        textF2.setBounds(new Rectangle(100,40,widthTF,heightTF));
        textF3=new JTextField();
        textF3.setBounds(new Rectangle(100,200,widthTF,heightTF));
        button=new JButton("+");
        button.setBounds(new Rectangle(120,115,widthB,heightB));
        textF1.setEditable(true);
        textF2.setEditable(true);
        textF3.setEditable(false);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                suma.calcular(textF1.getText(), textF2.getText())
            }
        });
        add(textF1);
        add(button);
        add(textF2);
        add(textF3);
        
        setLayout(null); 
        setPreferredSize(new Dimension(WIDTH, HEIGHT));
    }
    
}
